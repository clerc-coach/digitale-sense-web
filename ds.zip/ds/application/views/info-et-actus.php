<?php echo $page; ?>
<div class="row"></div>
<div class="row"></div>
<div class="container">
    <div class="row">
        <h4>Infos et actus</h4>
        <div class="row"></div>
        <div class="col s12 m12">
            <div class="card horizontal medium over">
                <div class="card-image small-img">
                    <img src="<?php echo img_url("scola.jpg"); ?>" alt="" srcset="">
                </div>
                <div class="card-stacked over">
                    <div class="card-content over">
                        <div class="avatar">
                            <img src="<?php echo img_url("scola.jpg"); ?>" alt="" srcset="" class="circle" width="80px" height="80px">
                            <h6><b>Nouvelles directives</b></h6>
                            <span class="blue-text">Par Carlos Maloba | 24 Mai 2019</span>
                        </div>
                        <div class="divider"></div>
                        <div class="row"></div>
                        <p class="justify">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Placeat illo modi repellendus praesentium suscipit optio nisi sapiente iste nobis ad fugit similique reprehenderit repudiandae veniam quibusdam, quis dolore eligendi itaque?</p>
                        <p class="truncate">
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Placeat illo modi repellendus praesentium suscipit optio nisi sapiente iste nobis ad fugit similique reprehenderit repudiandae veniam quibusdam, quis dolore eligendi itaque?
                        </p>
                    </div>
                    <div class="card-action small-img">
                        <div class="row">
                            <span class="left">1 Vue, <a href="">Rediger un commantaire</a></span>
                            <a href="http://" class="right red-text"><i class="material-icons">favorite_border</i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col s12 m12">
            <div class="card horizontal medium over">
                <div class="card-image small-img">
                    <img src="<?php echo img_url("scola.jpg"); ?>" alt="" srcset="">
                </div>
                <div class="card-stacked over">
                    <div class="card-content over">
                        <div class="avatar">
                            <img src="<?php echo img_url("scola.jpg"); ?>" alt="" srcset="" class="circle" width="80px" height="80px">
                            <h6><b>Nouvelles directives</b></h6>
                            <span class="blue-text">Par Carlos Maloba | 24 Mai 2019</span>
                        </div>
                        <div class="divider"></div>
                        <div class="row"></div>
                        <p class="justify">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Placeat illo modi repellendus praesentium suscipit optio nisi sapiente iste nobis ad fugit similique reprehenderit repudiandae veniam quibusdam, quis dolore eligendi itaque?</p>
                        <p class="truncate">
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Placeat illo modi repellendus praesentium suscipit optio nisi sapiente iste nobis ad fugit similique reprehenderit repudiandae veniam quibusdam, quis dolore eligendi itaque?
                        </p>
                    </div>
                    <div class="card-action small-img">
                        <div class="row">
                            <span class="left">1 Vue, <a href="">Rediger un commantaire</a></span>
                            <a href="http://" class="right red-text"><i class="material-icons">favorite_border</i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col s12 m12">
            <div class="card horizontal medium over">
                <div class="card-image small-img">
                    <img src="<?php echo img_url("scola.jpg"); ?>" alt="" srcset="">
                </div>
                <div class="card-stacked over">
                    <div class="card-content over">
                        <div class="avatar">
                            <img src="<?php echo img_url("scola.jpg"); ?>" alt="" srcset="" class="circle" width="80px" height="80px">
                            <h6><b>Nouvelles directives</b></h6>
                            <span class="blue-text">Par Carlos Maloba | 24 Mai 2019</span>
                        </div>
                        <div class="divider"></div>
                        <div class="row"></div>
                        <p class="justify">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Placeat illo modi repellendus praesentium suscipit optio nisi sapiente iste nobis ad fugit similique reprehenderit repudiandae veniam quibusdam, quis dolore eligendi itaque?</p>
                        <p class="truncate">
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Placeat illo modi repellendus praesentium suscipit optio nisi sapiente iste nobis ad fugit similique reprehenderit repudiandae veniam quibusdam, quis dolore eligendi itaque?
                        </p>
                    </div>
                    <div class="card-action small-img">
                        <div class="row">
                            <span class="left">1 Vue, <a href="">Rediger un commantaire</a></span>
                            <a href="http://" class="right red-text"><i class="material-icons">favorite_border</i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row"></div>
<div class="divider"></div>

<?php
echo $contact;
echo $footer; 
?>