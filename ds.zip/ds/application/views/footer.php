<footer class="page-footer grey lighten-3">
    <div class="container">
        <div class="row">
            <div class="col s12 m4">
                <h5 class="grey-text text-darken-3">Liens</h5>
                <ul>
                    <li><a href="http://" class="grey-text text-darken-2">A propos</a></li>
                    <li><a href="http://" class="grey-text text-darken-2">Services</a></li>
                    <li><a href="http://" class="grey-text text-darken-2">Infos et actus</a></li>
                    <li><a href="http://" class="grey-text text-darken-2">Contact</a></li>
                </ul>
            </div>
            <div class="col s12 m4">
                <h5 class="grey-text text-darken-3">Services</h5>
                <span class="grey-text text-darken-2">Réseaux informatiques et Maintenance</span>
                <span class="grey-text text-darken-2">Conception des systèmes informatiques</span>
                <span class="grey-text text-darken-2">Design et Multimédia</span>
            </div>
            <div class="col s12 m4">
                <h5 class="grey-text text-darken-3">Contacts</h5>
            </div>
        </div>
    </div>
    <div class="footer-copyright grey lighten-1">
        <div class="container black-text">
            &copy Copyright <script>document.write(new Date().getFullYear());</script>
            <a href="http://" class="grey-text text-darken-2 right">Designed by Clerc</a>
        </div>
    </div>
</footer>