<?php echo $page; ?>


<div class="row"></div>
<div class="row"></div>
<div class="container">
    <div class="row">
        <div class="col s12 m8">
            <h4>A propos de nous</h4>
            <p class="grey-text text-darken-3 justify">Nous sommes Digital Sense S.A.R.L., societé basé dans la recherche, le développement, et la conception des systèmes informatiques. Les produits et services que nous offrons sont, pour la plus part, le fruit du développement basé sur plusieurs cas d'utilisations dans nos laboratoires garantissant ainsi leurs qualités pour qu'il repondent au mieux aux besoins et aux attentes du client. Plusieurs projets sont en ce même en cours de développement pour des sorties très prochaines. Il s'agit notamment de <a href="http://">HomeSense</a>; un système de domotique et de controle flux d'énergie électrique, YetuPay une plateforme de paiement en ligne et Mybster(<a href="http://">BoxSeller</a>) une plateforme de e-commerce.</p>

            <p class="grey-text text-darken-3 justify">Nous sommes également basés dans la consultance où nous partageons notre experience au profit des particuliers et des entreprises. Nous vous simplifions la vie grâce à nos services de réseaux informatiques qui vous assurent une facilité de transaction informationnelle. Notre équipe de maintenanciers vous est offerte pour ,d'une part, pour prévenir les eventuelles pannes avec un diagnostiques complet de vos systèmes informatiques. D'une autre part, en cas disfonctionnement total, elle procedera à son depannage complet.</p>
        </div>
    </div>
</div>
<div class="row"></div>
<div class="row"></div>
<div class="row grey lighten-3">
    <div class="container">
        <div class="row">
            <div class="row"></div>
            <div class="row"></div>
            <h4>Notre équipe</h4>
            <div class="row"></div>
            <div class="row"></div>
            <div class="row">
                <div class="col s12 m6">
                    <div class="row">
                        <div class="col s12 m3">
                            <img src="<?php echo img_url("scola.jpg") ?>" alt="" srcset="" width="100px" height="100px">
                        </div>
                        <div class="col s12 m9">
                            <h5>Scola Kabengele, Developpeur</h5>
                            <span class="blue-text"><a href="http://">isco@digitalsense.com</a> | +243 97 29 71 738</span>
                        </div>
                        <div class="col s12 m12">
                            <p class="grey-text text-darken-3 justify">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam, enim, libero velit illo commodi quae esse accusamus debitis saepe quia corrupti sapiente incidunt eaque aperiam iure. Quae praesentium hic ea?
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col s12 m6">
                    <div class="row">
                        <div class="col s12 m3">
                            <img src="<?php echo img_url("scola.jpg") ?>" alt="" srcset="" width="100px" height="100px">
                        </div>
                        <div class="col s12 m9">
                            <h5>Scola Kabengele, Developpeur</h5>
                            <span class="blue-text"><a href="http://">isco@digitalsense.com</a> | +243 97 29 71 738</span>
                        </div>
                        <div class="col s12 m12">
                            <p class="grey-text text-darken-3 justify">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam, enim, libero velit illo commodi quae esse accusamus debitis saepe quia corrupti sapiente incidunt eaque aperiam iure. Quae praesentium hic ea?
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col s12 m6">
                    <div class="row">
                        <div class="col s12 m3">
                            <img src="<?php echo img_url("scola.jpg") ?>" alt="" srcset="" width="100px" height="100px">
                        </div>
                        <div class="col s12 m9">
                            <h5>Scola Kabengele, Developpeur</h5>
                            <span class="blue-text"><a href="http://">isco@digitalsense.com</a> | +243 97 29 71 738</span>
                        </div>
                        <div class="col s12 m12">
                            <p class="grey-text text-darken-3 justify">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam, enim, libero velit illo commodi quae esse accusamus debitis saepe quia corrupti sapiente incidunt eaque aperiam iure. Quae praesentium hic ea?
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col s12 m6">
                    <div class="row">
                        <div class="col s12 m3">
                            <img src="<?php echo img_url("scola.jpg") ?>" alt="" srcset="" width="100px" height="100px">
                        </div>
                        <div class="col s12 m9">
                            <h5>Scola Kabengele, Developpeur</h5>
                            <span class="blue-text"><a href="http://">isco@digitalsense.com</a> | +243 97 29 71 738</span>
                        </div>
                        <div class="col s12 m12">
                            <p class="grey-text text-darken-3 justify">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam, enim, libero velit illo commodi quae esse accusamus debitis saepe quia corrupti sapiente incidunt eaque aperiam iure. Quae praesentium hic ea?
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php
echo $contact;
echo $footer; 
?>
