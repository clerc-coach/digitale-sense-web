<?php echo $page; ?>

<div class="row"></div>
<div class="row"></div>
<div class="container">
    <div class="row">
        <h4>Nos services</h4>
        <div class="row"></div>
        <h5 class="grey-text darken-3 center-align">Réseaux informatiques et Maintenance</h5>
        <div class="row"></div>
        <div class="row"></div>
        <div class="row">
            <div class="col s12 m4 center-align">
                <span class="center-align"><img src="<?php echo img_url("globe.png") ?>" alt="" srcset="" width="100px" height="100px"></span>
                <p class="center-align">Implémentation de réseaux LAN, MAN et WAN</p>
                <p class="justify grey-text text-darken-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Natus unde </p>
            </div>
            <div class="col s12 m4 center-align">
                <span class="center-align"><img src="<?php echo img_url("service-cloud.png") ?>" alt="" srcset="" width="120px" height="100px"></span>
                <p class="center-align">Troubleshooting (Configuration des Switch, Router)</p>
                <p class="justify grey-text text-darken-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Natus unde </p>
            </div>
            <div class="col s12 m4 center-align">
                <span class="center-align"><img src="<?php echo img_url("transfer.png") ?>" alt="" srcset="" width="100px" height="100px"></span>
                <p class="center-align">Configuration des services (VOIP, MAIL, WEB, Vidéo Conférence)</p>
                <p class="justify grey-text text-darken-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Natus unde</p>
            </div>
        </div>
        <div class="row"></div>
        <div class="row"></div>
        <h5 class="grey-text darken-3 center-align">Conception des systèmes informatiques</h5>
        <div class="row"></div>
        <div class="row"></div>
        <div class="row">
            <div class="col s12 m4 center-align">
                <span class="center-align"><img src="<?php echo img_url("systeme-embarque.png") ?>" alt="" srcset="" width="110px" height="100px"></span>
                <p class="center-align">Conception et programmation des systèmes embarqués</p>
                <p class="justify grey-text text-darken-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Natus unde</p>
            </div>
            <div class="col s12 m4 center-align">
                <span class="center-align"><img src="<?php echo img_url("mobweb.png") ?>" alt="" srcset="" width="100px" height="100px"></span>
                <p class="center-align">Développement d'applications Web & Mobile</p>
                <p class="justify grey-text text-darken-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Natus unde</p>
            </div>
            <div class="col s12 m4 center-align">
                <span class="center-align"><img src="<?php echo img_url("object-connected.png") ?>" alt="" srcset="" width="100px" height="100px"></span>
                <p class="center-align">Solution Objets connectés & Internet des objets</p>
                <p class="justify grey-text text-darken-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Natus unde</p>
            </div>
        </div>
        <div class="row"></div>
        <div class="row"></div>
        <h5 class="grey-text darken-3 center-align">Design et Multimédia</h5>
        <div class="row"></div>
        <div class="row"></div>
        <div class="col s12 m4 center-align">
            <span class="center-align"><img src="<?php echo img_url("photo-video.png") ?>" alt="" srcset="" width="130px" height="100px"></span>
            <p class="center-align">Couvertures evenementielle (Photo & Vidéo)</p>
            <p class="justify grey-text text-darken-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Natus unde</p>
        </div>
        <div class="col s12 m4 center-align">
            <span class="center-align"><img src="<?php echo img_url("card.png") ?>" alt="" srcset="" width="130px" height="100px"></span>
            <p class="center-align">Conception graphique (Affiche, logo, carte de service)</p>
            <p class="justify grey-text text-darken-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Natus unde</p>
        </div>
        <div class="col s12 m4 center-align">
            <span class="center-align"><img src="<?php echo img_url("print.png") ?>" alt="" srcset="" width="130px" height="100px"></span>
            <p class="center-align">Impression sur tout type de support (Tissus, Bâche, Papier)</p>
            <p class="justify grey-text text-darken-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Natus unde</p>
        </div>
    </div>
    <div class="row">
        <div class="col s12 m12">
            <a href="<?php  ?>" class="center-align btn red green darken-2"></a>
        </div>
    </div>
</div>
<div class="row"></div>
<div class="divider"></div>
<?php
echo $contact;
echo $footer; 
?>