<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Digitale Sense</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo css_url("materialise"); ?>" />
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo css_url("font"); ?>" />
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo css_url("style"); ?>" />
    <script src="<?php echo js_url("materialize"); ?>"></script>
</head>
<body>
    <div class="navbar-fixed">
        <nav>
            <div class="nav-wrapper white">
                <div class="container">
                    <a href="#" class="brand-logo grey-text text-darken-2">Digital<span class="blue-text">Sense</span></a>               
                    <a href="#" data-target="mobile-demo" class="sidenav-trigger blue-text"><i class="material-icons">menu</i></a>
                    <ul class="right hide-on-med-and-down">
                        <li><a href="<?php echo site_url("panel/index"); ?>" class="grey-text text-darken-1">A propos</a></li>
                        <li><a href="<?php echo site_url("panel/services"); ?>" class="grey-text text-darken-1">Services</a></li>
                        <li><a href="<?php echo site_url("panel/infos"); ?>" class="grey-text text-darken-1">Infos et actus</a></li>
                        <li><a href="<?php echo site_url("panel/contact"); ?>" class="grey-text text-darken-1">Contacts</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <ul class="sidenav" id="mobile-demo">
        <h3 class="grey-text text-darken-2 center-align">Digital<span class="blue-text">Sense</span></h3>
        <div class="divider"></div>
        <li><a href="<?php echo site_url("panel/index"); ?>" class="grey-text text-darken-1">A propos</a></li>
        <li><a href="<?php echo site_url("panel/services"); ?>" class="grey-text text-darken-1">Services</a></li>
        <li><a href="<?php echo site_url("panel/infos"); ?>" class="grey-text text-darken-1">Infos et actus</a></li>            
        <li><a href="<?php echo site_url("panel/contact"); ?>" class="grey-text text-darken-1">Contacts</a></li>
    </ul>
    <div class="slider">
        <ul class="slides">
            <li>
                <img src="<?php echo img_url("header.jpg"); ?>" alt="" srcset="">
                <div class="caption left-align">
                    <h2>Digital Sense</h2>
                    <h5 class="light grey-text text-lighten-3">Le futur est à votre porte. Ouvrez lui, ouvrez nous</h5>
                </div>
            </li>
            <li>
                <img src="<?php echo img_url("banner1.jpeg"); ?>" alt="" srcset="">
                <div class="caption center-align">
                    <h2>Digital Sense</h2>
                    <h5 class="light grey-text text-lighten-3">Le futur est à votre porte. Ouvrez lui, ouvrez nous</h5>
                </div>
            </li>
        </ul>
    </div>
    


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.slider');
            var instances = M.Slider.init(elems, {
                indicators: false
            });
        });
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.sidenav');
            var instances = M.Sidenav.init(elems);
        });
    </script>
</body>
</html>