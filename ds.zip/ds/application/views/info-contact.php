<div class="row"></div>
<div class="row">
    <div class="container">
        <div class="row">
            <div class="col s12 m8">
                <h4>N'hésitez pas à nous contacter</h4>
            </div>
            <div class="col s12 m4">
                <div class="row"></div>
                <a href="<?php echo site_url("panel/contact"); ?>" class="btn-large red darken-1">Nous contacter</a>
            </div>
        </div>
    </div>
</div>