<?php echo $page; ?>
<div class="row"></div>
<div class="row"></div>
<div class="container">
    <div class="row">
        <h4>Contacts</h4>
        <div class="row">
            <div class="col s12 m6 z-depth-1 grey lighten-4" style="padding-top:2%;padding-bottom:2%;">
                <form action="" method="post">
                    <div class="col s12 m12 input-field">
                        <input type="email" name="" id="" class="validate">
                        <label for="">Nom</label>
                    </div>
                    <div class="col s12 m12 input-field">
                        <input type="email" name="" id="" class="validate">
                        <label for="">Email</label>
                    </div>
                    <div class="col s12 m12 input-field">
                        <input type="text" name="" id="" class="validate">
                        <label for="">Sujet</label>
                    </div>
                    <div class="col s12 m12 input-field">
                        <textarea id="textarea1" class="materialize-textarea"></textarea>
                        <label for="textarea1">Messages</label>
                    </div>
                    <div class="col s12 m12">
                        <button type="submit" class="btn blue">ENVOYER</button>
                    </div>
                </form>
            </div>
            <div class="col s12 m2 offset-m1">
                <h6>Notre adresse</h6>
                <span style="font-size:0.9em;" class="grey-text text-darken-2">1500 Avenue ... , Commune ..., Ville de Lubumbashi, RDC.</span>
            </div>
            <div class="col s12 m3">
                <h6>Nous joindre</h6>
                <span>Fax : +243 0000000000</span><br>
                <span>Phone : +243 0000000000</span><br>
                <span>Email : ds@dsc.org</span>
            </div>
        </div>
    </div>
</div>
<?php
    echo $footer;
?>