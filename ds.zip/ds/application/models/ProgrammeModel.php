<?php
/**
 * Created by PhpStorm.
 * User: GADNYZ
 * Date: 2019/05/03
 * Time: 03:23
 */

class ProgrammeModel extends CI_Model{
    public function __construct(){
        parent::__construct();
    }
    /**
     * 1. Retourne la liste de toutes les villes des agences disponible
     */
    public function enregistrer_client($data){
        $this->db->insert('client', $data);
        return $this->db->insert_id();
    }
    public function getListeVille()
    {
        $req ="select distinct(ville) as nom from (select * from admin  where etat = 1 order by ville )as t";
        return $this->db->query($req)->result();
    }
    /**
     * 2. Retourne la liste des compagnies
     */

    public function getListeCompagnies()
    {
        $req ="SELECT nomCompagnie, logo, modeTransport from compagnie where etat =1";
        return $this->db->query($req)->result();
    }
    /**
     * 3. Permet d'envoyer un email
     */
    public function sendEmail($data)
    {

    }
    /**
     * 4. Retourne les nombre des places d'un programme
     */
    public function getNombrePlace()
    {

    }
    /**
     * 5. Retourne tous les programmes d'une recherche
     */
    public function getProgrammes($origine, $destination, $date_depart,$nombrePersonne)
    {
        return $this->db->query("SELECT dateprogramme-curdate() as dif, origine, destination, jour,  DATE_FORMAT(dateprogramme, 'le %e - %m -
        %Y') as ladateformater, dateprogramme ,  heure, codeProgramme, montant, nomCompagnie, logo, modeTransport , telephone FROM programmes inner join compagnie
        on compagnie.codeCompagnie = programmes.codeCompagnie
                                    WHERE origine = '$origine'  
                                    AND destination = '$destination' 
                                    AND dateprogramme = '$date_depart' 
                                    AND modeTransport = 'Bus'
                                    ORDER BY heure ASC ")->result();
    }
    /**
     * 6. Retourne les infos d'un programme
     */
    public function getProgramme($codeProgramme)
    {
        return $this->db->query("SELECT dateprogramme-curdate() as dif, origine, destination, jour,  DATE_FORMAT(dateprogramme, 'le %e - %m -
        %Y') as ladateformater, dateprogramme ,  heure, codeProgramme, montant, nomCompagnie, logo, modeTransport , telephone FROM programmes inner join compagnie
        on compagnie.codeCompagnie = programmes.codeCompagnie
                                    WHERE codeProgramme = '$codeProgramme'
                                    ORDER BY heure ASC ")->result();
    }
    /**
     * 7. Inserer les infos d'une reservation
     */
    public function enregistrerReservation($data)
    {

    }
    /**
     * 8.
     */
    public function genererCode(){
        return $this->db->query("SELECT UCASE(SUBSTRING(sha1(concat(MAX(codeClient) ,nomClient)),1,7)) as code FROM client")->row_array()['code'];
    }
    /**
     * 9.
     */
    public function reserver($codeprogramme,$codeclient,$codereserv,$classe,$modePayement,$codeadmin )
    {
        $this->db->set('place',0)
            ->set('codeprogramme',$codeprogramme)
            ->set('datereservation','NOW()',false)
            ->set('codeclient',$codeclient)
            ->set('codereserv',$codereserv)
            ->set('codeClasse',$classe)
            ->set('modePayement',$modePayement)
            ->set('codeadmin',$codeadmin);
        $this->db->insert('reservation');
        return $this->db->insert_id();
    }
}