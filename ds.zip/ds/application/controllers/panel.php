<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Panel extends CI_Controller {

	// Page accueil - a propos
	public function index()
	{
		$this->load->helper('assets');
		$header = $this->load->view('header', [], true);
		$contact = $this->load->view('info-contact', [], true);
		$footer = $this->load->view('footer', [], true);
		$this->load->view("a-propos", ['page' => $header, 'footer' => $footer, 'contact' => $contact]);
	}
	// Page des services
	public function services(){
		$this->load->helper('assets');
		$header = $this->load->view('header', [], true);
		$contact = $this->load->view('info-contact', [], true);
		$footer = $this->load->view('footer', [], true);
		$this->load->view("services", ['page' => $header, 'footer' => $footer, 'contact' => $contact]);
	}
	// Page d'infos et actus
	public function infos(){
		$this->load->helper('assets');
		$header = $this->load->view('header', [], true);
		$contact = $this->load->view('info-contact', [], true);
		$footer = $this->load->view('footer', [], true);
		$this->load->view("info-et-actus", ['page' => $header, 'footer' => $footer, 'contact' => $contact]);
	}
	// Page des contacts
	public function contact(){
		$this->load->helper('assets');
		$header = $this->load->view('header', [], true);
		$contact = $this->load->view('info-contact', [], true);
		$footer = $this->load->view('footer', [], true);
		$this->load->view("contact", ['page' => $header, 'footer' => $footer, 'contact' => $contact]);
	}
}
