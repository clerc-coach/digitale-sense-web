-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2019 at 09:30 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itraveldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `codeAdmin` int(11) NOT NULL,
  `telephone` varchar(16) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `codeCompagnie` int(11) DEFAULT NULL,
  `password` varchar(128) NOT NULL,
  `ville` varchar(64) DEFAULT NULL,
  `username` varchar(16) NOT NULL,
  `type` int(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`codeAdmin`, `telephone`, `email`, `codeCompagnie`, `password`, `ville`, `username`, `type`) VALUES
(1, '+2439785965', 'yves@gmail.com', 2, '7c222fb2927d828af22f592134e8932480637c0d', 'LUBUMBASHI', 'yves', 0),
(2, '+234896525897', 'mac@esis.org', 16, '7c222fb2927d828af22f592134e8932480637c0d', 'KOLWEZI', 'mac', 0),
(3, '+24398685855', 'francois@gmail.com', 8, '7c222fb2927d828af22f592134e8932480637c0d', 'KOLWEZI', 'francois', 1),
(6, '+2438965888', 'gad@esis.org', 7, '7c222fb2927d828af22f592134e8932480637c0d', 'LUBUMBASHI', 'gad', 0),
(7, '+243585865', 'fils@gmail.com', 3, '7c222fb2927d828af22f592134e8932480637c0d', 'KOLWEZI', 'fils', 0),
(8, '0999035824', 'Mateo@gmail.com', 17, '7c222fb2927d828af22f592134e8932480637c0d', 'LUBUMBASHI', 'Mateo', 0),
(17, '6746728899', 'yndeturuye@gmail.com', 20, '7c222fb2927d828af22f592134e8932480637c0d', 'LUBUMBASHI', 'user1', 1),
(19, '98873751', 'yndeturuye@gmail.com', 18, '7c222fb2927d828af22f592134e8932480637c0d', 'LUBUMBASHI', 'yves1', 0),
(20, '87765544', 'yndeturuye@gmail.com', 18, '7c222fb2927d828af22f592134e8932480637c0d', 'LUBUMBASHI', 'yves2', 0),
(21, '897465271', 'francoiswalker285@gmail.com', 25, '7c222fb2927d828af22f592134e8932480637c0d', 'likasi', 'franc2', 0),
(22, '098776666', 'f@g.com', 28, '7c222fb2927d828af22f592134e8932480637c0d', 'LUBUMBASHI', 'user2', 0),
(23, '87755641°', '15yn453@esisalama.org', 28, '7c222fb2927d828af22f592134e8932480637c0d', 'LUBUMBASHI', 'mercian', 1),
(24, '98873751', 'yndeturuye@gmail.com', 18, '7c222fb2927d828af22f592134e8932480637c0d', 'LUBUMBASHI', 'franck', 0),
(31, '+243569585', '1234@G.com', 3, '7c222fb2927d828af22f592134e8932480637c0d', 'likasi', 'julien', 1),
(32, '123', '12345678@g.com', 3, '7c222fb2927d828af22f592134e8932480637c0d', 'FUNGURUME', 'yes', 0),
(33, '+21111', 'l@gmail.com', 16, '7c222fb2927d828af22f592134e8932480637c0d', 'LIKASI', 'nyembo', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE `bus` (
  `codeBus` int(11) NOT NULL,
  `nbPlace` smallint(6) DEFAULT NULL,
  `etat` tinyint(1) DEFAULT '1',
  `codeCompagnie` int(11) DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  `immatriculation` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`codeBus`, `nbPlace`, `etat`, `codeCompagnie`, `type`, `immatriculation`) VALUES
(94, 5, 1, 7, 'mini', '12kat/19'),
(95, 5, 1, 7, 'grand', '25'),
(96, 300, 1, 18, 'moyen', 'AirQ1'),
(97, 500, 1, 18, 'grand', '30KAT'),
(98, 600, 1, 18, 'grand', '10QT'),
(99, 500, 1, 16, 'moyen', 'BOYING20'),
(100, 20, 1, 2, 'mini', 'kat10');

-- --------------------------------------------------------

--
-- Table structure for table `categorie`
--

CREATE TABLE `categorie` (
  `codeCategorie` int(11) NOT NULL,
  `intitule` varchar(32) NOT NULL,
  `reduction` float NOT NULL,
  `codeAdmin` int(11) NOT NULL,
  `etat` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorie`
--

INSERT INTO `categorie` (`codeCategorie`, `intitule`, `reduction`, `codeAdmin`, `etat`) VALUES
(0, 'Simple', 2, 6, 1),
(12, 'Femme enceintes', 5, 24, 1),
(13, 'Femme enceintes', 5, 2, 1),
(14, 'Femme enceintes', 20, 1, 1),
(15, 'Handicaper', 5, 6, 1),
(16, 'personne agée', 10, 6, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `categories`
-- (See below for the actual view)
--
CREATE TABLE `categories` (
`codeCategorie` int(11)
,`intitule` varchar(32)
,`reduction` float
,`codeAdmin` int(11)
,`etat` tinyint(1)
,`codeCompagnie` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `classe`
--

CREATE TABLE `classe` (
  `codeClasse` int(11) NOT NULL,
  `nom` varchar(126) NOT NULL,
  `reduction` float NOT NULL,
  `codeAdmin` int(11) NOT NULL,
  `etat` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classe`
--

INSERT INTO `classe` (`codeClasse`, `nom`, `reduction`, `codeAdmin`, `etat`) VALUES
(0, 'Simple', 0, 24, 1),
(10, 'Economique', 5, 2, 1),
(11, 'Business', -5, 2, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `classement`
-- (See below for the actual view)
--
CREATE TABLE `classement` (
`nbPlace` smallint(6)
,`codeClasser` int(11)
,`origine` varchar(64)
,`dateprogramme` date
,`codecompagnie` int(11)
,`jour` varchar(8)
,`destination` varchar(64)
,`codeProgramme` int(11)
,`nom` varchar(126)
,`etat` tinyint(4)
);

-- --------------------------------------------------------

--
-- Table structure for table `classer`
--

CREATE TABLE `classer` (
  `codeClasser` int(11) NOT NULL,
  `codeProgramme` int(11) NOT NULL,
  `codeClasse` int(11) NOT NULL,
  `nbPlace` smallint(6) NOT NULL,
  `etat` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classer`
--

INSERT INTO `classer` (`codeClasser`, `codeProgramme`, `codeClasse`, `nbPlace`, `etat`) VALUES
(1, 25, 11, 200, 0),
(2, 25, 0, 200, 1),
(3, 25, 10, 100, 1),
(4, 11, 0, 200, 1),
(5, 15, 10, 300, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `classes`
-- (See below for the actual view)
--
CREATE TABLE `classes` (
`codeClasse` int(11)
,`nom` varchar(126)
,`reduction` float
,`codeAdmin` int(11)
,`etat` tinyint(1)
,`codeCompagnie` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `codeClient` int(11) NOT NULL,
  `nomClient` varchar(32) DEFAULT NULL,
  `postnomClient` varchar(32) DEFAULT NULL,
  `prenomClient` varchar(64) DEFAULT NULL,
  `adresse` text,
  `genre` varchar(1) NOT NULL,
  `codeadmin` int(11) NOT NULL,
  `categorie` int(11) NOT NULL,
  `codeCategorie` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`codeClient`, `nomClient`, `postnomClient`, `prenomClient`, `adresse`, `genre`, `codeadmin`, `categorie`, `codeCategorie`) VALUES
(1, 'GAD', 'MALULU', 'JNK', 'KHJ', 'H', 2, 0, 13),
(2, 'katanga', 'kongolo', 'francois', 'je ne sais pas', 'H', 2, 0, 0),
(3, 'KILOLO', 'LOLI', 'JEANPY', 'je ne sais pas', 'H', 2, 0, 0),
(4, 'KONGOLO', 'JILIO', 'LOP', 'KIOL', 'H', 33, 0, 0),
(5, 'YESU', 'JESUS', 'MASIYA', 'CIEL', 'H', 33, 0, 0),
(6, 'kjhvb', 'kjjhbv', 'oiuhgv', 'oiuhg', 'H', 33, 0, 0),
(7, 'kjhgv', 'ihjgvb ', 'iuhjvb ', 'lkjhbv', 'H', 33, 0, 0),
(8, 'njhg', 'knjhbvc', 'hjgvc', 'jhbvgc', 'H', 33, 0, 0),
(9, 'GAD', 'kjhg', 'hgvc', 'ihjbv', 'H', 33, 0, 0),
(10, ',jhsgd', 'hjgf', 'kjhbv', 'jhgv', 'H', 33, 0, 0),
(11, 'MATTHIEU', 'KISIMBA', 'M', 'MB', 'H', 33, 0, 0),
(12, 'MATTHIEU', 'KISIMBA', 'M', 'MB', 'H', 33, 0, 0),
(13, 'MATTHIEU', 'KISIMBA', 'M', 'MB', 'H', 33, 0, 0),
(14, 'MATTHIEU', 'KISIMBA', 'M', 'MB', 'H', 33, 0, 0),
(15, 'MATTHIEU', 'KISIMBA', 'M', 'MB', 'H', 33, 0, 0),
(16, 'MATTHIEU', 'KISIMBA', 'M', 'MB', 'H', 33, 0, 0),
(17, 'MATTHIEU', 'KISIMBA', 'M', 'MB', 'H', 33, 0, 0),
(18, 'MATTHIEU', 'KISIMBA', 'M', 'MB', 'H', 33, 0, 0),
(19, 'MATTHIEU', 'KISIMBA', 'M', 'MB', 'H', 33, 0, 0),
(20, 'jkhg', 'hjgf', 'ijuhg', 'fhg', 'F', 33, 0, 0),
(21, 'kjhbv', 'kjbn', 'kjnb', 'kjhb', 'H', 33, 0, 0),
(22, 'njbhvhgft', 'uyghvb', 'uyghvb', 'uyghvb ', 'F', 33, 0, 13),
(23, 'GAD', 'BOTINO', 'GODQLO', 'BEL qir', 'H', 6, 0, 16),
(24, 'opi', 'jy', 'jhg', 'jhg', 'F', 6, 0, 15),
(25, 'GAD', 'MALULU', 'JNK', 'KHJ', 'F', 6, 0, 15),
(26, 'GAD', 'MALULU', 'yjhgvu', 'KHJ', 'H', 6, 0, 0),
(27, 'YVES', 'NUMBI', 'HULAIN', 'Bel ville', 'H', 2, 0, 13),
(28, 'jhg', 'jh', 'kjh', 'kjh', 'H', 2, 0, 0),
(29, 'MARTIN', 'FAYULU', 'MAYALA', '14 Bel Air, Lubumbashi', 'F', 6, 0, 15),
(30, 'GAD', 'MALULU', 'GF', 'hyujh', 'H', 6, 0, 15),
(31, 'GAD', 'GF', 'JKN?', 'gh', 'F', 6, 0, 15),
(32, 'GAD', 'MALULU', 'JKN?', 'KHJ', 'H', 6, 0, 0),
(33, 'GAD', 'MALULU', 'JNK', 'KHJ', 'H', 6, 0, 15),
(34, 'YVES', 'MALULU', 'JNK', 'KHJ', 'F', 6, 0, 0),
(35, 'GAD', 'MALULU', 'JNK', 'KHJ', 'H', 6, 0, 15),
(36, 'GAD', 'MALULU', 'JKN?', 'hyujh', 'F', 6, 0, 0),
(37, 'FRANCOIS', 'J', 'OL', 'JH', 'H', 6, 0, 15),
(38, 'GAD', 'MALULU', 'JNK', 'gh', 'H', 6, 0, 0),
(39, 'YVES', 'GF', 'GF', 'KHJ', 'H', 6, 0, 0),
(40, 'GAD', 'njh', 'JNK', 'KHJ', 'F', 6, 0, 15);

-- --------------------------------------------------------

--
-- Table structure for table `compagnie`
--

CREATE TABLE `compagnie` (
  `codeCompagnie` int(11) NOT NULL,
  `nomCompagnie` varchar(64) DEFAULT NULL,
  `description` varchar(128) DEFAULT NULL,
  `logo` varchar(128) DEFAULT NULL,
  `modeTransport` varchar(32) NOT NULL,
  `telephone` varchar(16) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `etat` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `compagnie`
--

INSERT INTO `compagnie` (`codeCompagnie`, `nomCompagnie`, `description`, `logo`, `modeTransport`, `telephone`, `email`, `etat`) VALUES
(2, 'RATKO', 'Rien a dire de nous', 'uploads/logo/RATKbus.png', 'Bus', '+2439685852741', 'ngfdtrans@gmail.com', 1),
(3, 'Mulycap', 'rien a dire', 'uploads/logo/Mulycapmulikap.png', 'Bus', '+2436958669', 'mulycap@gmail.com', 1),
(4, 'transcat', 'rien a dire', 'uploads/logo/bus.jpg', 'Bus', '+243896969558', 'transkat@gmail.com', 1),
(7, 'San', 'rien a dire', 'uploads/logo/Sanbus.png', 'Bus', '+243896565825', 'san@gmail.com', 1),
(8, 'efeTrans', 'rien a dire', 'uploads/logo/bus.jpg', 'Bus', '+2439685669', 'efeTrans@gmail.com', 1),
(15, 'congo airways', 'rien a dire', 'uploads/logo/bus.jpg', 'Avion', '++2345859635', 'congoairways@gmail.com', 1),
(16, 'CongoAirways', 'rien a dire', 'uploads/logo/CongoAirwaysairplane106.png', 'Avion', '+2438968558', 'CongoAirways@gmail.com', 1),
(17, 'Mulykap', '<em>Veuillez donner une petite description</em>', 'uploads/logo/bus.jpg', 'Bus', '0999035824', 'mande@gmail.com', 1),
(18, 'QUATAR AIRWAYS', NULL, 'uploads/logo/bus.jpg', 'avion', NULL, 'QT@gmail.com', 1),
(19, 'ETHIOPIAN ', NULL, 'uploads/logo/bus.jpg', 'avion', NULL, 'et@gmail.com', 0),
(20, 'SAFARI', 'uwiegfoQHP\'\'Kc nVN \"pvoVQJOEVV', 'uploads/logo/bus.jpg', 'avion', '0997123', 'safari@gmail.com', 1),
(21, 'yeStravel', NULL, 'uploads/logo/bus.jpg', 'Bus', NULL, '15yn453@esisalama.org', 0),
(22, 'comTravel', NULL, 'uploads/logo/bus.jpg', 'Bus', NULL, 'yndeturuye@gmail.com', 0),
(24, 'TRANSCO', NULL, 'uploads/logo/bus.jpg', 'Bus', NULL, '15yn453@esisalama.org', 1),
(25, 'Turkish AIRLINE', NULL, 'uploads/logo/bus.jpg', 'Bus', NULL, 'yndeturuye@gmail.org', 1),
(26, 'Vejor Trans', NULL, 'uploads/logo/bus.jpg', 'Avion', NULL, '15yn453@esisalama.org', 1),
(27, 'Fygm Trans', NULL, 'uploads/logo/bus.jpg', 'Bus', NULL, 'yndeturuye@gmail.com', 1),
(28, 'buffer Travel', 'GIMFbnviojbngvzibvn   H', 'uploads/logo/bus.jpg', 'Avion', '09876655644', '15yn453@esisalama.org', 1);

--
-- Triggers `compagnie`
--
DELIMITER $$
CREATE TRIGGER `insertToTempo` AFTER INSERT ON `compagnie` FOR EACH ROW INSERT INTO tempo  VALUES (null,new.codeCompagnie,Sha1(new.nomCompagnie))
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateLogoCompagnie` BEFORE INSERT ON `compagnie` FOR EACH ROW IF new.modeTransport='avion' THEN
	SET new.logo='uploads/logo/avion.png';
ELSE
	 SET new.logo='uploads/logo/bus.png';

END if
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `horairehebdo`
--

CREATE TABLE `horairehebdo` (
  `codeHoraire` int(11) NOT NULL,
  `jour` varchar(8) NOT NULL,
  `codetarif` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `horairehebdo`
--

INSERT INTO `horairehebdo` (`codeHoraire`, `jour`, `codetarif`) VALUES
(107, 'lundi', 21),
(108, 'mardi', 21),
(109, 'mercredi', 21),
(110, 'jeudi', 21),
(111, 'vendredi', 21),
(112, 'samedi', 21),
(113, 'lundi', 22),
(114, 'jeudi', 22),
(115, 'vendredi', 22),
(116, 'lundi', 23),
(117, 'mardi', 23),
(118, 'mercredi', 23),
(119, 'jeudi', 23),
(120, 'vendredi', 23),
(121, 'lundi', 24),
(122, 'vendredi', 24),
(123, 'samedi', 24),
(124, 'dimanche', 24),
(125, 'lundi', 25),
(126, 'mercredi', 25),
(127, 'vendredi', 25),
(128, 'samedi', 25),
(129, 'lundi', 26),
(130, 'mercredi', 26),
(131, 'jeudi', 26),
(132, 'dimanche', 26),
(133, 'lundi', 27),
(134, 'mercredi', 27),
(135, 'vendredi', 27),
(136, 'lundi', 28),
(137, 'vendredi', 28),
(138, 'samedi', 28),
(139, 'dimanche', 28),
(140, 'mardi', 29),
(141, 'mercredi', 29),
(142, 'jeudi', 29),
(143, 'samedi', 29),
(144, 'lundi', 30),
(145, 'mardi', 30),
(146, 'jeudi', 30),
(147, 'vendredi', 30),
(148, 'dimanche', 30),
(149, 'lundi', 31),
(150, 'jeudi', 31),
(151, 'vendredi', 31),
(152, 'dimanche', 31),
(163, 'lundi', 32),
(164, 'mardi', 32);

--
-- Triggers `horairehebdo`
--
DELIMITER $$
CREATE TRIGGER `afectToJournal` AFTER DELETE ON `horairehebdo` FOR EACH ROW INSERT INTO journalhoraire (codeJournal,codeHoraire,codeTarif,jour,date)  VALUES (null,old.codeHoraire,old.codetarif,old.jour,now())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `imodelizadmin`
--

CREATE TABLE `imodelizadmin` (
  `codeadmin` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(64) NOT NULL,
  `firstconnexion` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `imodelizadmin`
--

INSERT INTO `imodelizadmin` (`codeadmin`, `username`, `password`, `email`, `firstconnexion`) VALUES
(1, 'justin', '7c222fb2927d828af22f592134e8932480637c0d', 'gad@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `journalhoraire`
--

CREATE TABLE `journalhoraire` (
  `codeJournal` int(11) NOT NULL,
  `codeHoraire` int(11) NOT NULL,
  `codeTarif` int(11) NOT NULL,
  `jour` varchar(8) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `journalhoraire`
--

INSERT INTO `journalhoraire` (`codeJournal`, `codeHoraire`, `codeTarif`, `jour`, `date`) VALUES
(22, 106, 0, 'lundi', '2019-01-04 18:16:17'),
(25, 153, 32, 'lundi', '2019-01-10 21:50:53'),
(26, 154, 32, 'mercredi', '2019-01-10 21:50:53'),
(27, 155, 32, 'vendredi', '2019-01-10 21:50:53'),
(28, 156, 32, 'samedi', '2019-01-10 21:50:53'),
(29, 157, 32, 'dimanche', '2019-01-10 21:50:53'),
(30, 158, 32, 'lundi', '2019-01-10 21:51:04'),
(31, 159, 32, 'lundi', '2019-01-10 21:51:11'),
(32, 160, 32, 'lundi', '2019-01-10 21:51:56'),
(35, 161, 32, 'lundi', '2019-01-10 21:52:42'),
(37, 162, 32, 'lundi', '2019-01-10 22:03:50');

-- --------------------------------------------------------

--
-- Table structure for table `programme`
--

CREATE TABLE `programme` (
  `codeProgramme` int(11) NOT NULL,
  `dateprogramme` date DEFAULT NULL,
  `codebus` int(11) NOT NULL,
  `codeadmin` int(11) NOT NULL,
  `codehoraire` int(11) NOT NULL,
  `codecompagnie` int(11) DEFAULT NULL,
  `etat` tinyint(4) NOT NULL DEFAULT '1',
  `suspendre` int(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `programme`
--

INSERT INTO `programme` (`codeProgramme`, `dateprogramme`, `codebus`, `codeadmin`, `codehoraire`, `codecompagnie`, `etat`, `suspendre`) VALUES
(4, '2019-01-04', 94, 6, 111, 7, 0, 0),
(5, '2019-01-05', 94, 6, 112, 7, 0, 0),
(6, '2019-01-07', 95, 6, 113, 7, 1, 0),
(7, '2019-01-08', 94, 6, 108, 7, 0, 0),
(8, '2019-01-05', 96, 24, 123, 18, 1, 0),
(9, '2019-01-06', 96, 24, 124, 18, 1, 0),
(10, '2019-01-05', 98, 24, 128, 18, 1, 0),
(11, '2019-01-07', 99, 2, 129, 16, 0, 0),
(12, '2019-01-07', 100, 1, 133, 2, 1, 0),
(13, '2019-01-07', 100, 1, 133, 2, 1, 0),
(14, '2019-01-07', 100, 1, 133, 2, 1, 0),
(15, '2019-01-07', 99, 2, 129, 16, 1, 0),
(16, '2019-01-07', 95, 6, 107, 7, 1, 0),
(17, '2019-01-11', 94, 6, 115, 7, 0, 0),
(18, '2019-01-07', 95, 6, 136, 7, 1, 0),
(19, '2019-01-08', 94, 6, 108, 7, 1, 0),
(20, '2019-01-08', 95, 6, 108, 7, 0, 0),
(21, '2019-01-07', 95, 6, 136, 7, 1, 0),
(22, '2019-01-12', 95, 6, 138, 7, 1, 0),
(23, '2019-01-27', 95, 6, 139, 7, 1, 0),
(24, '2019-10-19', 94, 6, 112, 7, 1, 0),
(25, '2019-01-09', 99, 2, 130, 16, 1, 0),
(26, '2019-01-10', 99, 2, 131, 16, 1, 0),
(27, '2019-01-08', 95, 6, 140, 7, 0, 0),
(28, '2019-01-08', 95, 6, 140, 7, 1, 0),
(29, '2019-01-08', 99, 2, 145, 16, 1, 0),
(30, '2019-01-09', 94, 6, 141, 7, 1, 0),
(31, '2019-01-09', 94, 6, 141, 7, 1, 0),
(32, '2019-01-09', 95, 6, 109, 7, 1, 0),
(33, '2019-01-10', 94, 6, 114, 7, 1, 0),
(34, '2019-01-10', 95, 6, 142, 7, 1, 0),
(35, '2019-01-10', 99, 2, 150, 16, 1, 0),
(36, '2019-01-11', 99, 2, 151, 16, 1, 0),
(37, '2019-01-14', 99, 2, 163, 16, 1, 0),
(38, '2019-01-15', 94, 6, 140, 7, 1, 1),
(39, '2019-01-14', 95, 6, 136, 7, 1, 0),
(40, '2019-01-14', 94, 6, 136, 7, 1, 1),
(41, '2019-01-14', 95, 6, 107, 7, 1, 0),
(42, '2019-01-18', 94, 6, 111, 7, 0, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `programmes`
-- (See below for the actual view)
--
CREATE TABLE `programmes` (
`immatriculation` varchar(10)
,`codehoraire` int(11)
,`codeProgramme` int(11)
,`dateprogramme` date
,`codebus` int(11)
,`codeadmin` int(11)
,`codecompagnie` int(11)
,`jour` varchar(8)
,`codetarif` int(11)
,`origine` varchar(64)
,`destination` varchar(64)
,`heure` time
,`montant` float
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `programme_classe`
-- (See below for the actual view)
--
CREATE TABLE `programme_classe` (
`codeClasser` int(11)
,`codeProgramme` int(11)
,`codeClasse` int(11)
,`nom` varchar(126)
,`reduction` float
);

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `codereservation` int(11) NOT NULL,
  `place` int(11) DEFAULT '0',
  `codeprogramme` int(11) DEFAULT NULL,
  `datereservation` datetime DEFAULT NULL,
  `codeClient` int(11) DEFAULT NULL,
  `codereserv` varchar(12) NOT NULL,
  `codeClasse` int(11) NOT NULL,
  `modePayement` varchar(32) NOT NULL,
  `codeAdmin` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`codereservation`, `place`, `codeprogramme`, `datereservation`, `codeClient`, `codereserv`, `codeClasse`, `modePayement`, `codeAdmin`) VALUES
(2, 0, 25, '2019-01-09 11:49:11', 2, '20003KF216', 0, 'Cash', 2),
(3, 0, 25, '2019-01-09 11:49:27', 3, '20004KJ216', 0, 'Cash', 2),
(4, 0, 25, '2019-01-09 12:39:59', 4, '330005KL3316', 0, 'Cash', 33),
(5, 0, 25, '2019-01-09 13:05:04', 5, '330006YM3316', 11, 'Cash', 33),
(6, 0, 25, '2019-01-09 13:05:58', 6, '330007KO3316', 0, 'Cash', 33),
(7, 0, 25, '2019-01-09 13:06:34', 7, '330008KI3316', 0, 'Cash', 33),
(8, 0, 25, '2019-01-09 13:07:21', 8, '330009NH3316', 0, 'Cash', 33),
(9, 0, 25, '2019-01-09 13:08:05', 9, '33010GH3316', 0, 'Cash', 33),
(10, 0, 25, '2019-01-09 13:08:53', 10, '33011,K3316', 0, 'Cash', 33),
(11, 0, 25, '2019-01-09 13:09:28', 11, '33012MM3316', 0, 'Cash', 33),
(12, 0, 25, '2019-01-09 13:09:32', 12, '33013MM3316', 0, 'Cash', 33),
(13, 0, 25, '2019-01-09 13:09:34', 13, '33014MM3316', 0, 'Cash', 33),
(14, 0, 25, '2019-01-09 13:09:34', 14, '33015MM3316', 0, 'Cash', 33),
(15, 0, 25, '2019-01-09 13:09:35', 15, '33016MM3316', 0, 'Cash', 33),
(16, 0, 25, '2019-01-09 13:09:35', 16, '33017MM3316', 0, 'Cash', 33),
(17, 0, 25, '2019-01-09 13:09:36', 17, '33018MM3316', 0, 'Cash', 33),
(18, 0, 25, '2019-01-09 13:09:37', 18, '33019MM3316', 0, 'Cash', 33),
(19, 0, 25, '2019-01-09 13:09:38', 19, '33020MM3316', 0, 'Cash', 33),
(20, 0, 25, '2019-01-09 13:11:20', 20, '33021JI3316', 0, 'Cash', 33),
(21, 0, 25, '2019-01-09 13:12:08', 21, '33022KK3316', 0, 'Cash', 33),
(22, 0, 25, '2019-01-09 13:12:27', 22, '33023NU3316', 11, 'Cash', 33),
(23, 0, 33, '2019-01-10 09:55:23', 23, '6024GG67', 0, 'Cash', 6),
(24, 0, 33, '2019-01-10 09:55:47', 24, '6025OJ67', 0, 'Cash', 6),
(25, 0, 33, '2019-01-10 20:26:56', 25, '6026GJ67', 0, 'Cash', 6),
(26, 0, 34, '2019-01-10 20:59:04', 26, '6027GY67', 0, 'Cash', 6),
(27, 0, 35, '2019-01-10 21:37:47', 27, '2028YH216', 0, 'Cash', 2),
(28, 0, 37, '2019-01-14 12:57:50', 28, '2029JK216', 0, 'Cash', 2),
(29, 0, 24, '2019-01-14 19:15:29', 29, '6030MM67', 0, 'Cash', 6),
(30, 0, 23, '2019-01-14 19:16:08', 30, '6031GG67', 0, 'Cash', 6),
(31, 0, 40, '2019-01-14 19:32:25', 31, '6032GJ67', 0, 'Cash', 6),
(32, 0, 40, '2019-01-14 19:32:35', 32, '6033GJ67', 0, 'Cash', 6),
(33, 0, 40, '2019-01-14 19:32:48', 33, '6034GJ67', 0, 'Cash', 6),
(34, 0, 40, '2019-01-14 19:32:59', 34, '6035YJ67', 0, 'Cash', 6),
(35, 0, 40, '2019-01-14 19:33:09', 35, '6036GJ67', 0, 'Cash', 6),
(36, 0, 42, '2019-01-18 06:40:20', 36, '6037GJ67', 0, 'Cash', 6),
(37, 0, 42, '2019-01-18 06:41:22', 37, '6038FO67', 0, 'Cash', 6),
(38, 0, 42, '2019-01-18 06:41:36', 38, '6039GJ67', 0, 'Cash', 6),
(39, 0, 42, '2019-01-18 06:41:47', 39, '6040YG67', 0, 'Cash', 6),
(40, 0, 42, '2019-01-18 06:42:01', 40, '6041GJ67', 0, 'Cash', 6);

--
-- Triggers `reservation`
--
DELIMITER $$
CREATE TRIGGER `insertIntoAnnulation` BEFORE DELETE ON `reservation` FOR EACH ROW INSERT INTO reservationannule VALUES(old.codereservation,old.place,old.codeprogramme,old.datereservation,old.codeClient,old.codereserv,old.modePayement,old.codeAdmin)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `reservationannule`
--

CREATE TABLE `reservationannule` (
  `codereservation` int(4) NOT NULL,
  `place` varchar(8) NOT NULL,
  `codeprogramme` int(11) NOT NULL,
  `datereservation` datetime NOT NULL,
  `codeClient` int(11) NOT NULL,
  `codreserv` varchar(12) NOT NULL,
  `codeClasse` int(11) NOT NULL,
  `modePayement` varchar(32) NOT NULL,
  `codeAdmin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `reservations`
-- (See below for the actual view)
--
CREATE TABLE `reservations` (
`codeAdmin` int(11)
,`ville` varchar(64)
,`codecompagnie` int(11)
,`nomClient` varchar(32)
,`postnomClient` varchar(32)
,`prenomClient` varchar(64)
,`genre` varchar(1)
,`reductioncategorie` float
,`intitule` varchar(32)
,`reductionclasse` float
,`nclasse` varchar(126)
,`codereservation` int(11)
,`codereserv` varchar(12)
,`modePayement` varchar(32)
,`place` int(11)
,`codeProgramme` int(11)
,`dateprogramme` date
,`suspendre` int(4)
,`nbPlace` smallint(6)
,`codeHoraire` int(11)
,`jour` varchar(8)
,`codeTarif` int(11)
,`heure` time
,`origine` varchar(64)
,`destination` varchar(64)
,`montant` float
);

-- --------------------------------------------------------

--
-- Table structure for table `tarif`
--

CREATE TABLE `tarif` (
  `codeTarif` int(11) NOT NULL,
  `montant` float DEFAULT NULL,
  `destination` varchar(64) DEFAULT NULL,
  `origine` varchar(64) DEFAULT NULL,
  `heure` time DEFAULT NULL,
  `etat` tinyint(1) DEFAULT '1',
  `codeAdmin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tarif`
--

INSERT INTO `tarif` (`codeTarif`, `montant`, `destination`, `origine`, `heure`, `etat`, `codeAdmin`) VALUES
(21, 20000, 'KASUMBALESA', 'LUBUMBASHI', '08:10:00', 1, 6),
(22, 15000, 'KASUMBALESA', 'LUBUMBASHI', '19:00:00', 1, 6),
(23, 500000, 'LUBUMBASHI', 'KINSHASA', '10:00:00', 1, 24),
(24, 500000, 'KINSHASA', 'LUBUMBASHI', '10:00:00', 1, 24),
(25, 900, 'LUBUMBASHI', 'JOANESBOURG', '18:00:00', 1, 24),
(26, 500000, 'LUBUMBASI', 'FUNGURUME', '10:00:00', 1, 2),
(27, 400, 'KASUMBALESA', 'LUBUMBASHI', '10:00:00', 1, 1),
(28, 500000, 'MATADI', 'LUBUMBASHI', '10:00:00', 1, 6),
(29, 6000, 'KINDU', 'LUBUMBASHI', '20:00:00', 1, 6),
(30, 600, 'KOLWEZI', 'LUBUMBASHI', '08:00:00', 1, 2),
(31, 20000, 'KASUMBALESA', 'KOLWEZI', '12:00:00', 1, 2),
(32, 30000, 'KALEMIE', 'KOLWEZI', '07:30:00', 1, 2);

-- --------------------------------------------------------

--
-- Stand-in structure for view `tarifs`
-- (See below for the actual view)
--
CREATE TABLE `tarifs` (
`codeTarif` int(11)
,`codeAdmin` int(11)
,`montant` float
,`destination` varchar(64)
,`origine` varchar(64)
,`heure` time
,`etat` tinyint(1)
,`codeCompagnie` int(11)
,`codeHoraire` int(11)
,`jour` varchar(8)
);

-- --------------------------------------------------------

--
-- Table structure for table `tempo`
--

CREATE TABLE `tempo` (
  `id` int(11) NOT NULL,
  `codeCompagnie` int(4) NOT NULL,
  `nomCompagnie` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure for view `categories`
--
DROP TABLE IF EXISTS `categories`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `categories`  AS  select `categorie`.`codeCategorie` AS `codeCategorie`,`categorie`.`intitule` AS `intitule`,`categorie`.`reduction` AS `reduction`,`admin`.`codeAdmin` AS `codeAdmin`,`categorie`.`etat` AS `etat`,`admin`.`codeCompagnie` AS `codeCompagnie` from (`categorie` join `admin` on((`admin`.`codeAdmin` = `categorie`.`codeAdmin`))) ;

-- --------------------------------------------------------

--
-- Structure for view `classement`
--
DROP TABLE IF EXISTS `classement`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `classement`  AS  select `classer`.`nbPlace` AS `nbPlace`,`classer`.`codeClasser` AS `codeClasser`,`programmes`.`origine` AS `origine`,`programmes`.`dateprogramme` AS `dateprogramme`,`programmes`.`codecompagnie` AS `codecompagnie`,`programmes`.`jour` AS `jour`,`programmes`.`destination` AS `destination`,`programmes`.`codeProgramme` AS `codeProgramme`,`classe`.`nom` AS `nom`,`classer`.`etat` AS `etat` from ((`classer` join `programmes` on((`classer`.`codeProgramme` = `programmes`.`codeProgramme`))) join `classe` on((`classer`.`codeClasse` = `classe`.`codeClasse`))) order by `programmes`.`dateprogramme` desc ;

-- --------------------------------------------------------

--
-- Structure for view `classes`
--
DROP TABLE IF EXISTS `classes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `classes`  AS  select `classe`.`codeClasse` AS `codeClasse`,`classe`.`nom` AS `nom`,`classe`.`reduction` AS `reduction`,`admin`.`codeAdmin` AS `codeAdmin`,`classe`.`etat` AS `etat`,`admin`.`codeCompagnie` AS `codeCompagnie` from (`classe` join `admin` on((`admin`.`codeAdmin` = `classe`.`codeAdmin`))) ;

-- --------------------------------------------------------

--
-- Structure for view `programmes`
--
DROP TABLE IF EXISTS `programmes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `programmes`  AS  select `bus`.`immatriculation` AS `immatriculation`,`programme`.`codehoraire` AS `codehoraire`,`programme`.`codeProgramme` AS `codeProgramme`,`programme`.`dateprogramme` AS `dateprogramme`,`programme`.`codebus` AS `codebus`,`programme`.`codeadmin` AS `codeadmin`,`programme`.`codecompagnie` AS `codecompagnie`,`horairehebdo`.`jour` AS `jour`,`horairehebdo`.`codetarif` AS `codetarif`,`tarif`.`origine` AS `origine`,`tarif`.`destination` AS `destination`,`tarif`.`heure` AS `heure`,`tarif`.`montant` AS `montant` from (((`programme` join `horairehebdo` on((`programme`.`codehoraire` = `horairehebdo`.`codeHoraire`))) join `tarif` on((`horairehebdo`.`codetarif` = `tarif`.`codeTarif`))) join `bus` on((`programme`.`codebus` = `bus`.`codeBus`))) where (`programme`.`etat` = 1) ;

-- --------------------------------------------------------

--
-- Structure for view `programme_classe`
--
DROP TABLE IF EXISTS `programme_classe`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `programme_classe`  AS  select `classer`.`codeClasser` AS `codeClasser`,`programme`.`codeProgramme` AS `codeProgramme`,`classe`.`codeClasse` AS `codeClasse`,`classe`.`nom` AS `nom`,`classe`.`reduction` AS `reduction` from ((`classer` join `programme` on((`classer`.`codeProgramme` = `programme`.`codeProgramme`))) join `classe` on((`classer`.`codeClasse` = `classe`.`codeClasse`))) ;

-- --------------------------------------------------------

--
-- Structure for view `reservations`
--
DROP TABLE IF EXISTS `reservations`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reservations`  AS  select `admin`.`codeAdmin` AS `codeAdmin`,`admin`.`ville` AS `ville`,`pgm`.`codecompagnie` AS `codecompagnie`,`client`.`nomClient` AS `nomClient`,`client`.`postnomClient` AS `postnomClient`,`client`.`prenomClient` AS `prenomClient`,`client`.`genre` AS `genre`,`categorie`.`reduction` AS `reductioncategorie`,`categorie`.`intitule` AS `intitule`,`classe`.`reduction` AS `reductionclasse`,`classe`.`nom` AS `nclasse`,`res`.`codereservation` AS `codereservation`,`res`.`codereserv` AS `codereserv`,`res`.`modePayement` AS `modePayement`,`res`.`place` AS `place`,`pgm`.`codeProgramme` AS `codeProgramme`,`pgm`.`dateprogramme` AS `dateprogramme`,`pgm`.`suspendre` AS `suspendre`,`bus`.`nbPlace` AS `nbPlace`,`horairehebdo`.`codeHoraire` AS `codeHoraire`,`horairehebdo`.`jour` AS `jour`,`tarif`.`codeTarif` AS `codeTarif`,`tarif`.`heure` AS `heure`,`tarif`.`origine` AS `origine`,`tarif`.`destination` AS `destination`,`tarif`.`montant` AS `montant` from ((((((((`reservation` `res` join `programme` `pgm` on((`res`.`codeprogramme` = `pgm`.`codeProgramme`))) join `bus` on((`pgm`.`codebus` = `bus`.`codeBus`))) join `horairehebdo` on((`pgm`.`codehoraire` = `horairehebdo`.`codeHoraire`))) join `tarif` on((`horairehebdo`.`codetarif` = `tarif`.`codeTarif`))) join `client` on((`res`.`codeClient` = `client`.`codeClient`))) join `categorie` on((`client`.`codeCategorie` = `categorie`.`codeCategorie`))) join `classe` on((`res`.`codeClasse` = `classe`.`codeClasse`))) join `admin` on((`res`.`codeAdmin` = `admin`.`codeAdmin`))) ;

-- --------------------------------------------------------

--
-- Structure for view `tarifs`
--
DROP TABLE IF EXISTS `tarifs`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `tarifs`  AS  select `tarif`.`codeTarif` AS `codeTarif`,`tarif`.`codeAdmin` AS `codeAdmin`,`tarif`.`montant` AS `montant`,`tarif`.`destination` AS `destination`,`tarif`.`origine` AS `origine`,`tarif`.`heure` AS `heure`,`tarif`.`etat` AS `etat`,`admin`.`codeCompagnie` AS `codeCompagnie`,`horairehebdo`.`codeHoraire` AS `codeHoraire`,`horairehebdo`.`jour` AS `jour` from ((`tarif` join `admin` on((`tarif`.`codeAdmin` = `admin`.`codeAdmin`))) join `horairehebdo` on((`tarif`.`codeTarif` = `horairehebdo`.`codetarif`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`codeAdmin`),
  ADD KEY `fk_compagnie_Admin` (`codeCompagnie`);

--
-- Indexes for table `bus`
--
ALTER TABLE `bus`
  ADD PRIMARY KEY (`codeBus`),
  ADD KEY `fk_compagnie_bus` (`codeCompagnie`);

--
-- Indexes for table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`codeCategorie`);

--
-- Indexes for table `classe`
--
ALTER TABLE `classe`
  ADD PRIMARY KEY (`codeClasse`);

--
-- Indexes for table `classer`
--
ALTER TABLE `classer`
  ADD PRIMARY KEY (`codeClasser`),
  ADD KEY `fk_classe` (`codeClasse`),
  ADD KEY `fk_programme` (`codeProgramme`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`codeClient`),
  ADD KEY `fk_client_admin` (`codeadmin`),
  ADD KEY `fk_categorie` (`categorie`);

--
-- Indexes for table `compagnie`
--
ALTER TABLE `compagnie`
  ADD PRIMARY KEY (`codeCompagnie`),
  ADD UNIQUE KEY `telephone` (`telephone`);

--
-- Indexes for table `horairehebdo`
--
ALTER TABLE `horairehebdo`
  ADD PRIMARY KEY (`codeHoraire`),
  ADD KEY `fk_tarif_horaire` (`codetarif`);

--
-- Indexes for table `imodelizadmin`
--
ALTER TABLE `imodelizadmin`
  ADD PRIMARY KEY (`codeadmin`);

--
-- Indexes for table `journalhoraire`
--
ALTER TABLE `journalhoraire`
  ADD PRIMARY KEY (`codeJournal`);

--
-- Indexes for table `programme`
--
ALTER TABLE `programme`
  ADD PRIMARY KEY (`codeProgramme`),
  ADD KEY `fk_admin` (`codeadmin`),
  ADD KEY `fk_bus` (`codebus`),
  ADD KEY `fk_compagnie` (`codecompagnie`),
  ADD KEY `fk_horaire` (`codehoraire`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`codereservation`),
  ADD KEY `fk_admin_reserv` (`codeAdmin`);

--
-- Indexes for table `reservationannule`
--
ALTER TABLE `reservationannule`
  ADD PRIMARY KEY (`codereservation`);

--
-- Indexes for table `tarif`
--
ALTER TABLE `tarif`
  ADD PRIMARY KEY (`codeTarif`);

--
-- Indexes for table `tempo`
--
ALTER TABLE `tempo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `codeAdmin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `bus`
--
ALTER TABLE `bus`
  MODIFY `codeBus` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `codeCategorie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `classe`
--
ALTER TABLE `classe`
  MODIFY `codeClasse` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `classer`
--
ALTER TABLE `classer`
  MODIFY `codeClasser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `codeClient` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `compagnie`
--
ALTER TABLE `compagnie`
  MODIFY `codeCompagnie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `horairehebdo`
--
ALTER TABLE `horairehebdo`
  MODIFY `codeHoraire` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;
--
-- AUTO_INCREMENT for table `imodelizadmin`
--
ALTER TABLE `imodelizadmin`
  MODIFY `codeadmin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `journalhoraire`
--
ALTER TABLE `journalhoraire`
  MODIFY `codeJournal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `programme`
--
ALTER TABLE `programme`
  MODIFY `codeProgramme` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `codereservation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `tarif`
--
ALTER TABLE `tarif`
  MODIFY `codeTarif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `programme`
--
ALTER TABLE `programme`
  ADD CONSTRAINT `fk_admin` FOREIGN KEY (`codeadmin`) REFERENCES `admin` (`codeAdmin`),
  ADD CONSTRAINT `fk_bus` FOREIGN KEY (`codebus`) REFERENCES `bus` (`codeBus`),
  ADD CONSTRAINT `fk_compagnie` FOREIGN KEY (`codecompagnie`) REFERENCES `compagnie` (`codeCompagnie`),
  ADD CONSTRAINT `fk_horaire` FOREIGN KEY (`codehoraire`) REFERENCES `horairehebdo` (`codeHoraire`);

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `fk_admin_reserv` FOREIGN KEY (`codeAdmin`) REFERENCES `admin` (`codeAdmin`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
